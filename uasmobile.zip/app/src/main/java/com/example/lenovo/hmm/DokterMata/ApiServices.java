package com.example.lenovo.hmm.DokterMata;

import com.example.lenovo.hmm.DokterMata.ResponseBerita;

import retrofit2.Call;
import retrofit2.http.GET;


public interface ApiServices {

    //@TIPEMETHOD("API_END_POINT")
    @GET("tampil_dokter_mata.php")
    Call<ResponseBerita> request_show_all_berita();
    // <ModelData> nama_method()

}