package com.example.lenovo.hmm.DokterGigi;

import retrofit2.Call;
import retrofit2.http.GET;



public interface ApiServices {

    //@TIPEMETHOD("API_END_POINT")
    @GET("tampil_dokter.php")
    Call<ResponseBerita> request_show_all_berita();
    // <ModelData> nama_method()

}