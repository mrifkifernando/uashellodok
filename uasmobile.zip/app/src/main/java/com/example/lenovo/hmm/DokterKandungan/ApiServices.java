package com.example.lenovo.hmm.DokterKandungan;

import com.example.lenovo.hmm.DokterKandungan.ResponseBerita;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiServices {

    //@TIPEMETHOD("API_END_POINT")
    @GET("tampil_dokter_kandungan.php")
    Call<ResponseBerita> request_show_all_berita();
    // <ModelData> nama_method()

}