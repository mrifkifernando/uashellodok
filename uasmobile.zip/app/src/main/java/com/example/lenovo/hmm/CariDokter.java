package com.example.lenovo.hmm;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.example.lenovo.hmm.DokterAnak.DokterAnak;
import com.example.lenovo.hmm.DokterGigi.DokterGigi;
import android.widget.EditText;
import android.widget.Toast;

import com.example.lenovo.hmm.DokterKandungan.DokterKandungan;
import com.example.lenovo.hmm.DokterMata.DokterMata;
import com.example.lenovo.hmm.DokterPatologiAnatomi.DokterPatologiAnatomi;
import com.example.lenovo.hmm.DokterUmum.DokterUmum;
import com.google.firebase.auth.FirebaseAuth;

public class CariDokter extends AppCompatActivity implements View.OnClickListener {

    Button gigi, kandungan, anak, patologi_anatomi, mata, umum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cari_dokter);
        gigi = (Button) findViewById(R.id.gigi);
        anak = (Button) findViewById(R.id.anak);
        kandungan = (Button) findViewById(R.id.kandungan);
        umum = (Button) findViewById(R.id.umum);
        mata= (Button) findViewById(R.id.mata);
        patologi_anatomi = (Button) findViewById(R.id.patologi_anatomi);
        gigi.setOnClickListener(this);
        kandungan.setOnClickListener(this);
        anak.setOnClickListener(this);
        umum.setOnClickListener(this);
        mata.setOnClickListener(this);
        patologi_anatomi.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.gigi:
                Intent explicit = new Intent(CariDokter.this, DokterGigi.class);
                startActivity(explicit);
                break;
        }
        switch (view.getId()) {
            case R.id.umum:
                Intent explicit = new Intent(CariDokter.this, DokterUmum.class);
                startActivity(explicit);
                break;
        }
        switch (view.getId()) {
            case R.id.anak:
                Intent explicit = new Intent(CariDokter.this, DokterAnak.class);
                startActivity(explicit);
                break;
        }
        switch (view.getId()) {
            case R.id.kandungan:
                Intent explicit = new Intent(CariDokter.this, DokterKandungan.class);
                startActivity(explicit);
                break;
        }
        switch (view.getId()) {
            case R.id.patologi_anatomi:
                Intent explicit = new Intent(CariDokter.this, DokterPatologiAnatomi.class);
                startActivity(explicit);
                break;
        }
        switch (view.getId()) {
            case R.id.mata:
                Intent explicit = new Intent(CariDokter.this, DokterMata.class);
                startActivity(explicit);
                break;
        }
    }
}